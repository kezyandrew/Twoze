<footer class="footer">
    <div class="container-fluid">
       
        <div class="copyright">
            &copy; {{ now()->year }} {{ _('made with') }} <i class="tim-icons icon-heart-2"></i>
            <span class="text-dark">{{ _('Laundering') }}</span>
             {{ _('for a better web') }}.
        </div>
    </div>
</footer>
