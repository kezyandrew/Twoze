<div class="container-fluid sidebar_open <?php if($errors->any()): ?> show_sidebar <?php endif; ?>" id="show_coupon_sidebar">
    <div class="row">
        <div class="col">
            <div class="card py-3 border-0">
                <!-- Card header -->
                <div class="border_bottom_primary pb-3 pt-2 mb-4">
                    <span class="h3"><?php echo e(__('View Coupon')); ?></span>
                    <button type="button" class="show_coupon_close close">&times;</button>
                </div>
                
                <div class="card card-profile shadow">
                    <div class="card-body p-2">
                        <div class="text-center">

                            <div class="table1">
                                <div class="row mt-3 mb-2">
                                    <div class="col h4 text-right rtl-align-left"><?php echo e(__('Code :')); ?></div>
                                    <div class="col text-left" id="coupon_code"></div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col h4 text-right rtl-align-left"><?php echo e(__('Maximum use :')); ?></div>
                                    <div class="col text-left" id="coupon_max_use"></div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col h4 text-right rtl-align-left"><?php echo e(__('Used :')); ?></div>
                                    <div class="col text-left" id="coupon_use_count"></div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col h4 text-right rtl-align-left"><?php echo e(__('Type :')); ?></div>
                                    <div class="col text-left" id="coupon_type"></div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col h4 text-right rtl-align-left"><?php echo e(__('Discount :')); ?></div>
                                    <div class="col text-left" id="coupon_discount"></div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col h4 text-right rtl-align-left"><?php echo e(__('Start date :')); ?></div>
                                    <div class="col text-left" id="coupon_start_date"></div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col h4 text-right rtl-align-left"><?php echo e(__('End date :')); ?></div>
                                    <div class="col text-left" id="coupon_end_date"></div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col h4 text-right rtl-align-left"><?php echo e(__('Status :')); ?></div>
                                    <div class="col text-left" id="coupon_status"></div>
                                </div>
                            </div>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('coupon_edit')): ?>
                                <div class="text-center">
                                    <button type="button" id="edit_btn" onclick="" class="btn edit_coupon_btn btn-primary mt-4 mb-5"><?php echo e(__('Edit Coupon')); ?></button>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp_old\htdocs\App\resources\views/admin/coupon/couponShow.blade.php ENDPATH**/ ?>