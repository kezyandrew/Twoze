<div class="container-fluid sidebar_open <?php if($errors->any()): ?> show_sidebar_create <?php endif; ?>" id="add_role_sidebar">
    <div class="row">
        <div class="col">
            <div class="card py-3 border-0">
                <!-- Card header -->
                <div class="border_bottom_primary pb-3 pt-2 mb-4">
                    <span class="h3"><?php echo e(__('Create Role')); ?></span>
                    <button type="button" class="add_role close">&times;</button>
                </div>
                <form class="form-horizontal"  id="create_role_form" method="post" enctype="multipart/form-data" action="<?php echo e(url('/admin/role')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="my-0">
                        <div class="form-group">
                            <label class="form-control-label" for="title"><?php echo e(__('Role Title')); ?></label>
                            <input type="text" value="<?php echo e(old('title')); ?>" name="title" id="title" class="form-control" placeholder="<?php echo e(__('Role Title')); ?>"  autofocus>
                            <div class="invalid-div "><span class="title"></span></div>
                        </div>
                    
                        
                        <div class="form-group">
                            <label class="form-control-label" for="permission"><?php echo e(__('Select Permissions')); ?></label>
                            <select class="form-control select2" dir="<?php echo e(session()->has('direction')&& session('direction') == 'rtl'? 'rtl':''); ?>" multiple="multiple" name="permission[]"  value="<?php echo e(old('Permission')); ?>"  data-placeholder='<?php echo e(__("-- Select Permissions --")); ?>'>
                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value=<?php echo e($per->id); ?>><?php echo e($per->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <div class="invalid-div "><span class="permission"></span></div>
                        </div>
                        
                        <div class="text-center">
                            <button type="button" id="create_btn" onclick="all_create('create_role_form','role')" class="btn btn-primary mt-4 mb-5"><?php echo e(__('Create')); ?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp_old\htdocs\App\resources\views/admin/role/roleCreate.blade.php ENDPATH**/ ?>