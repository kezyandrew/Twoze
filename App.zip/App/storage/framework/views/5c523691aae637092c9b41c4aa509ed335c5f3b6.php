<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        
        <!-- Title -->
        <?php $app_name = \App\Models\AppSetting::first()->app_name; ?>
        <title><?php echo e($app_name); ?></title>
        
         <!-- Dynamic color -->
        <?php $color = \App\Models\AppSetting::first()->color; ?>
        <style>
            :root{
                --primary_color : <?php echo $color ?>;
                --primary_color_hover : <?php echo $color.'cc' ?>;
            }
        </style>
            
        <!-- Favicon -->
        <?php $favicon = \App\Models\AppSetting::first()->favicon; ?>
        <link href="<?php echo e(asset('/images/app/'.$favicon)); ?>" rel="icon" type="image/png">

        <!-- Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">

        <!-- Icons -->
        <link rel="stylesheet" href="<?php echo e(asset('admin/css/nucleo.css')); ?>" type="text/css">
        <link rel="stylesheet" href="<?php echo e(asset('admin/css/all.min.css')); ?>" type="text/css">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800&display=swap" rel="stylesheet">

        <!--  CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('admin/css/login.css')); ?>" type="text/css">
    </head>

    
<body class="login">

    <section class="main-area">
        <div class="container-fluid">
            <div class="row h100">
                <?php $bg_img = \App\Models\AppSetting::first()->bg_img; ?>
                <div class="col-md-6 p-0 m-none" style="background: url(<?php echo e(asset('/images/app/'.$bg_img)); ?>) center center;background-size: cover;background-repeat: no-repeat;">
                    <span class="mask bg-gradient-dark opacity-6"></span>
                </div>

                <div class="col-md-6 p-0">
                    <div class="login">
                        <div class="center-box">
                            <div class="logo">
                                <?php $color_logo = \App\Models\AppSetting::first()->color_logo; ?>
                                <img src="<?php echo e(asset('/images/app/'.$color_logo)); ?>" class="logo-img">
                            </div>
                            <div class="title">
                                
                                <h4 class="login_head"><?php echo e(__('Admin Login')); ?></h4>
                                <p class="login-para"><?php echo e(__('This is a secure system and you will need to provide your')); ?> <br>
                                    <?php echo e(__('login details to access the site.')); ?></p>
                            </div>
                            <div class="form-wrap">
                                <form role="form" class="pui-form" id="loginform"  method="POST" action="<?php echo e(url('/admin_login_check')); ?>">
                                <?php echo csrf_field(); ?>
                                    <div class="pui-form__element">
                                        <label class="animated-label <?php echo e(old('email') != null ? 'moveUp': ''); ?>"><?php echo e(__('Email')); ?></label>
                                        <input id="inputEmail" name="email" type="email" class="form-control   <?php echo e(old('email') != null ? 'outline': ''); ?> <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  value="<?php echo e(old('email')); ?>" placeholder="">
                                            
                                    </div>
                                    <div class="pui-form__element">
                                        <label class="animated-label"><?php echo e(__('Password')); ?></label>
                                        <input id="inputPassword" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" placeholder="">
                                            
                                    </div>
                                    <?php if($errors->any()): ?>
                                        <br><h4 class="text-center text-red"><?php echo e($errors->first()); ?></h4><br>
                                    <?php endif; ?>
                                    <div class="pui-form__element">
                                        <button class="btn btn-lg btn-primary btn-block btn-salon" type="submit"><?php echo e(__('SIGN IN')); ?></button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="<?php echo e(asset('admin/js/myjavascript.js')); ?>"></script>
</body>
 
</html><?php /**PATH C:\xampp_old\htdocs\App\resources\views/admin/loginPages/login.blade.php ENDPATH**/ ?>