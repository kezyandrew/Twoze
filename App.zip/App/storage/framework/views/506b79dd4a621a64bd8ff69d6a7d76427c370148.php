
<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('layouts.breadcrumb', [
            'title' => __('Orders'),
            'class' => 'col-lg-7'
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <!-- Page content -->
    <div class="container-fluid mt--6">
        <div class="row">
            <div class="col">
                <div class="card">
                    <!-- Card header -->
                    <div class="card-header">
                        <h3 class="mb-0"><?php echo e(__('Orders table')); ?></h3>
                        
                    </div>
                    <!-- Light table -->
                    <div class="table-responsive">
                        <table class="table align-items-center table-flush" id="dataTableReport">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col" class="sort"><?php echo e(__('#')); ?></th>
                                    <th scope="col" class="sort"><?php echo e(__('Order ID')); ?></th>
                                    <th scope="col" class="sort"><?php echo e(__('User ID')); ?></th>
                                    <th scope="col" class="sort"><?php echo e(__('Delivery Date')); ?></th>
                                    <th scope="col" class="sort"><?php echo e(__('Discount')); ?></th>
                                    <th scope="col" class="sort"><?php echo e(__('Payment')); ?></th>
                                    <th scope="col" class="sort badge-center"><?php echo e(__('Payment Status')); ?></th>
                                    <th scope="col" class="sort"><?php echo e(__('Order status')); ?></th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody class="list">
                                <?php if(count($orders) != 0): ?>
                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th> <?php echo e($loop->iteration); ?> </th>
                                            <td> <?php echo e($order->order_id); ?> </td>
                                            <td> <?php echo e($order->user->name); ?> </td>
                                            <td> <?php echo e($order->date); ?> </td>
                                            <td> <?php echo e($currency_symbol); ?><?php echo e($order->discount); ?> </td>
                                            <td> <?php echo e($currency_symbol); ?><?php echo e($order->payment); ?> </td>
                                            <td class="badge-center">
                                                <?php if($order->payment_status == 0): ?>
                                                    <span class="badge badge-pill badge-warning"><?php echo e(__('Unpaid')); ?></span>
                                                <?php else: ?>
                                                    <?php if($order->payment_type == "CASH"): ?>
                                                        <span class="badge badge-pill badge-success"><?php echo e(__('CASH')); ?></span>
                                                    <?php elseif($order->payment_type == "RAZORPAY"): ?>
                                                        <span class="badge badge-pill badge-success"><?php echo e(__('RAZORPAY')); ?></span>
                                                    <?php elseif($order->payment_type == "PAYPAL"): ?>
                                                        <span class="badge badge-pill badge-success"><?php echo e(__('PAYPAL')); ?></span>
                                                    <?php elseif($order->payment_type == "STRIPE"): ?>
                                                        <span class="badge badge-pill badge-success"><?php echo e(__('STRIPE')); ?></span>
                                                    <?php else: ?>
                                                        <span class="badge badge-pill badge-success"><?php echo e(__('Paid')); ?></span>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('order_edit')): ?>
                                                    
                                                        <select class="form-control statusDD" onchange="changeStatus(<?php echo e($order->id); ?>)" name="selector" id="selector<?php echo e($order->id); ?>" <?php echo e($order->order_status == "Completed" || $order->order_status == "Cancel"?'disabled': ''); ?> >
                                                        <option value="Pending" <?php echo e($order->order_status == "Pending"?'selected': ''); ?>>Pending</option>
                                                        <option value="Cancel" <?php echo e($order->order_status == "Cancel"?'selected': ''); ?>>Cancel</option>
                                                        <option value="Completed" <?php echo e($order->order_status == "Completed"?'selected': ''); ?>>Completed</option>
                                                    </select>
                                                <?php endif; ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(!'order_edit')): ?>
                                                    <?php if($order->order_status == "Pending"): ?>
                                                        <span class="badge badge-dot mr-4">
                                                            <i class="bg-warning"></i>
                                                            <span class="status">Pending</span>
                                                        </span>
                                                    <?php elseif($order->order_status == "Cancel"): ?>
                                                        <span class="badge badge-dot mr-4">
                                                            <i class="bg-danger"></i>
                                                            <span class="status">Cancel</span>
                                                        </span>
                                                    <?php elseif($order->order_status == "Completed"): ?>
                                                        <span class="badge badge-dot mr-4">
                                                            <i class="bg-success"></i>
                                                            <span class="status">Completed</span>
                                                        </span>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </td>
                                            <td class="table-actions">
                                                <a href="<?php echo e(url('/admin/order/invoice/'.$order->id)); ?>" class="text-blue cursor table-action">
                                                    <i class="fas fa-file-invoice"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <?php $no_data = \App\Models\AppSetting::first()->no_data; ?>
                                    <tr>
                                        <td colspan="11" class="text-center">
                                            <img class="nodata-img" src="<?php echo e(asset('/images/app/'.$no_data)); ?>" alt="">
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_old\htdocs\App\resources\views/admin/order/orderTable.blade.php ENDPATH**/ ?>