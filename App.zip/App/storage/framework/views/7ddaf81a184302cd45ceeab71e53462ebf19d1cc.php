
<?php $__env->startSection('content_setting'); ?>

    <?php echo $__env->make('layouts.breadcrumb', [
            'title' => __('Settings'),
            'class' => 'col-lg-7'
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <!-- Page content -->
    <div class="container-fluid mt--6">
        <div class="row">
            <div class="col">
                <div class="card">
                    <!-- Card header -->
                    <div class="card-header">
                        <h3 class="mb-0"><?php echo e(__('Settings')); ?></h3>
                    </div>
                    
                    <div class="row mt-3">
                        <div class="col-3 pl-5">
                            <div class="nav-wrapper settings">
                                <ul class="nav navbar-nav nav-pills setting nav-fill" id="tabs-icons-text" role="tablist">
                                    <li class="nav-item">
                                        <a class="nav-link text-left <?php echo e($setting->license_status == 0 ? 'pointer-none': ''); ?> <?php echo e($setting->license_status == 1 ? 'active': ''); ?>" id="tabs-icons-text-1-tab" data-toggle="tab" href="#tab-1" role="tab" aria-controls="tabs-icons-text-1" aria-selected="true"><i class="fa fa-user mr-2"></i> <?php echo e(__('OTP Verification')); ?> </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link text-left <?php echo e($setting->license_status == 0 ? 'pointer-none': ''); ?>" id="tabs-icons-text-2-tab" data-toggle="tab" href="#tab-2" role="tab" aria-controls="tabs-icons-text-2" aria-selected="false"><i class="fas fa-money-bill-alt mr-2"></i> <?php echo e(__('Currency')); ?> </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link text-left <?php echo e($setting->license_status == 0 ? 'pointer-none': ''); ?>" id="tabs-icons-text-13-tab" data-toggle="tab" href="#tab-13" role="tab" aria-controls="tabs-icons-text-13" aria-selected="false"><i class="fas fa-map-pin mr-2"></i> <?php echo e(__('Map')); ?> </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link text-left <?php echo e($setting->license_status == 0 ? 'pointer-none': ''); ?>" id="tabs-icons-text-12-tab" data-toggle="tab" href="#tab-12" role="tab" aria-controls="tabs-icons-text-12" aria-selected="false"><i class="fa fa-map-marker-alt mr-2"></i> <?php echo e(__('Address')); ?> </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link text-left <?php echo e($setting->license_status == 0 ? 'pointer-none': ''); ?>" id="tabs-icons-text-3-tab" data-toggle="tab" href="#tab-3" role="tab" aria-controls="tabs-icons-text-3" aria-selected="false"><i class="fa fa-bell mr-2"></i> <?php echo e(__('Push Notification')); ?> </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link text-left <?php echo e($setting->license_status == 0 ? 'pointer-none': ''); ?>" id="tabs-icons-text-4-tab" data-toggle="tab" href="#tab-4" role="tab" aria-controls="tabs-icons-text-4" aria-selected="false"><i class="far fa-envelope mr-2"></i> <?php echo e(__('Email Settings')); ?> </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link text-left <?php echo e($setting->license_status == 0 ? 'pointer-none': ''); ?>" id="tabs-icons-text-5-tab" data-toggle="tab" href="#tab-5" role="tab" aria-controls="tabs-icons-text-5" aria-selected="false"><i class="fas fa-sms mr-2"></i> <?php echo e(__('SMS Gateway')); ?> </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link text-left <?php echo e($setting->license_status == 0 ? 'pointer-none': ''); ?>" id="tabs-icons-text-6-tab" data-toggle="tab" href="#tab-6" role="tab" aria-controls="tabs-icons-text-6" aria-selected="false"><i class="far fa-credit-card mr-2"></i> <?php echo e(__('Payment Gateway')); ?> </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link text-left <?php echo e($setting->license_status == 0 ? 'pointer-none': ''); ?>" id="tabs-icons-text-7-tab" data-toggle="tab" href="#tab-7" role="tab" aria-controls="tabs-icons-text-7" aria-selected="false"><i class="fa fa-gavel mr-2"></i> <?php echo e(__('Terms Of Use')); ?> </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link text-left <?php echo e($setting->license_status == 0 ? 'pointer-none': ''); ?>" id="tabs-icons-text-8-tab" data-toggle="tab" href="#tab-8" role="tab" aria-controls="tabs-icons-text-8" aria-selected="false"><i class="fa fa-lock mr-2"></i> <?php echo e(__('Privacy Policy')); ?> </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link text-left <?php echo e($setting->license_status == 0 ? 'pointer-none': ''); ?>" id="tabs-icons-text-9-tab" data-toggle="tab" href="#tab-9" role="tab" aria-controls="tabs-icons-text-9" aria-selected="false"><i class="fa fa-cube mr-2"></i> <?php echo e(__('App Settings')); ?> </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link text-left <?php echo e($setting->license_status == 0 ? 'pointer-none': ''); ?>" id="tabs-icons-text-10-tab" data-toggle="tab" href="#tab-10" role="tab" aria-controls="tabs-icons-text-10" aria-selected="false"><i class="fa fa-image mr-2"></i> <?php echo e(__('Admin Settings')); ?> </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link text-left <?php echo e($setting->license_status == 0 ? 'active': ''); ?>" id="tabs-icons-text-11-tab" data-toggle="tab" href="#tab-11" role="tab" aria-controls="tabs-icons-text-11" aria-selected="false"><i class="fa fa-id-card mr-2"></i> <?php echo e(__('License')); ?> </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-9 mt-3 pr-6">
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger" role="alert">
                                    <strong><?php echo e(__('Error!')); ?></strong> <?php echo e($errors->first()); ?>

                                </div>
                            <?php endif; ?>
                            <?php if(session('status')): ?>
                                <div class="alert alert-danger" role="alert">
                                    <strong><?php echo e(__('Error!')); ?></strong> <?php echo e(session('status')); ?>

                                </div>
                            <?php endif; ?>
                            <div class="card shadow settings-main-body">
                                <div class="card-body">
                                    <div class="tab-content" id="myTabContent">
                                        <!-- OTP Verification --->
                                        <div class="tab-pane fade <?php echo e($setting->license_status == 1 ? 'active show': ''); ?>" id="tab-1" role="tabpanel" aria-labelledby="tabs-icons-text-1-tab">
                                            <form action="<?php echo e(url('/admin/setting/otp')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <h3 class="card-title"><?php echo e(__('OTP Verification')); ?></h3>
                                                
                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="verify_user"><?php echo e(__('Verification')); ?> </label>
                                                    <div class="col-sm-9 mt-2">
                                                        <label class="custom-toggle">
                                                            <input type="checkbox" id="verify_user" name="verify_user" <?php echo e($setting->verify_user == 1?'checked':''); ?>>
                                                            <span class="custom-toggle-slider rounded-circle" data-label-off="No" data-label-on="Yes"></span>
                                                        </label>
                                                    </div>
                                                </div>

                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="verify_user_sms"><?php echo e(__('SMS')); ?> </label>
                                                    <div class="col-sm-9 mt-2">
                                                        <label class="custom-toggle">
                                                            <input type="checkbox" id="verify_user_sms" name="verify_user_sms" <?php echo e($setting->verify_user_sms == 1?'checked':''); ?>>
                                                            <span class="custom-toggle-slider rounded-circle" data-label-off="No" data-label-on="Yes"></span>
                                                        </label>
                                                    </div>
                                                </div>

                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="verify_user_mail"><?php echo e(__('Email')); ?> </label>
                                                    <div class="col-sm-9 mt-2">
                                                        <label class="custom-toggle">
                                                            <input type="checkbox" id="verify_user_mail" name="verify_user_mail" <?php echo e($setting->verify_user_mail == 1?'checked':''); ?>>
                                                            <span class="custom-toggle-slider rounded-circle" data-label-off="No" data-label-on="Yes"></span>
                                                        </label>
                                                    </div>
                                                </div>
                                                
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('setting_edit')): ?>
                                                    <div class="border-top">
                                                        <div class="card-body text-center">
                                                            <input type="submit" class="btn btn-primary rtl-float-none" value="<?php echo e(__('Submit')); ?>">
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            </form>
                                        </div>

                                        <!-- currency --->
                                        <div class="tab-pane fade" id="tab-2" role="tabpanel" aria-labelledby="tabs-icons-text-2-tab">
                                            <form action="<?php echo e(url('/admin/setting/currency')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <h3 class="card-title"><?php echo e(__('Currency')); ?></h3>
                                                
                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label"><?php echo e(__('Select Currency')); ?></label>
                                                    <div class="col-sm-9 w-75">
                                                        <select class="form-control select2" dir="<?php echo e(session()->has('direction')&& session('direction') == 'rtl'? 'rtl':''); ?>" name="currency" id="currency" >
                                                            <?php $__currentLoopData = $currency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($cur->code); ?>" <?php echo e((collect(old('currency'))->contains($cur->code)) ? 'selected':''); ?> <?php if( $cur->code == $setting->currency_code){ echo "selected"; } ?>><?php echo e($cur->currency); ?> (<?php echo e($cur->symbol); ?> - <?php echo e($cur->code); ?>)</option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                        <?php if($setting->currency_code != "INR"): ?>
                                                            <div class="mt-3">
                                                                <?php echo e(__("Rozarpay doesn't support")); ?> <?php echo e($setting->currency_code); ?>

                                                            </div>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('setting_edit')): ?>
                                                    <div class="border-top">
                                                        <div class="card-body text-center">
                                                            <input type="submit" class="btn btn-primary rtl-float-none" value="<?php echo e(__('Submit')); ?>">
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            </form>
                                        </div>
                                        
                                        <!-- Map --->
                                        <div class="tab-pane fade" id="tab-13" role="tabpanel" aria-labelledby="tabs-icons-text-13-tab">
                                            <form action="<?php echo e(url('/admin/setting/map')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <h3 class="card-title"><?php echo e(__('Map')); ?></h3>
                                                
                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="mapkey"><?php echo e(__('Map Key')); ?></label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" value="<?php echo e(old('mapkey', $setting->mapkey)); ?>" name="mapkey" id="mapkey" placeholder="<?php echo e(__('Map Key')); ?>">
                                                        <?php $__errorArgs = ['mapkey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                            <div class="invalid-div"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div> 
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('setting_edit')): ?>
                                                    <div class="border-top">
                                                        <div class="card-body text-center">
                                                            <input type="submit" class="btn btn-primary rtl-float-none" value="<?php echo e(__('Submit')); ?>">
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            </form>
                                        </div>
                                        
                                        <!-- Address --->
                                        <div class="tab-pane fade form" id="tab-12" role="tabpanel" aria-labelledby="tabs-icons-text-12-tab">
                                            <form action="<?php echo e(url('/admin/setting/address')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <h3 class="card-title"><?php echo e(__('Address')); ?></h3>
                                                
                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="address1"><?php echo e(__('Address 1')); ?></label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" value="<?php echo e(old('address1', $setting->addr1)); ?>" name="address1" id="address1" placeholder="<?php echo e(__('Address 1')); ?>">
                                                        <?php $__errorArgs = ['address1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                            <div class="invalid-div"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div> 
                                                 
                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="address2"><?php echo e(__('Address 2')); ?></label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" value="<?php echo e(old('address2', $setting->addr2)); ?>" name="address2" id="address2" placeholder="<?php echo e(__('Address 2')); ?>">
                                                        <?php $__errorArgs = ['address2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                            <div class="invalid-div"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div> 
                                                 
                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="city"><?php echo e(__('City')); ?></label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" value="<?php echo e(old('city', $setting->city)); ?>" name="city" id="city" placeholder="<?php echo e(__('City')); ?>">
                                                        <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                            <div class="invalid-div"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div> 
                                                 
                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="state"><?php echo e(__('State')); ?></label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" value="<?php echo e(old('state', $setting->state)); ?>" name="state" id="state" placeholder="<?php echo e(__('State')); ?>">
                                                        <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                            <div class="invalid-div"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div> 
                                                 
                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="country"><?php echo e(__('Country')); ?></label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" value="<?php echo e(old('country', $setting->country)); ?>" name="country" id="country" placeholder="<?php echo e(__('Country')); ?>">
                                                        <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                            <div class="invalid-div"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div> 
                                                 
                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="zipcode"><?php echo e(__('Zipcode')); ?></label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" value="<?php echo e(old('zipcode', $setting->zipcode)); ?>" name="zipcode" id="zipcode" placeholder="<?php echo e(__('Zipcode')); ?>">
                                                        <?php $__errorArgs = ['zipcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                            <div class="invalid-div"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                                
                                                <div class="form-group row">
                                                    <div class="col-sm-3"></div>
                                                    <div class="col-sm-9 mapsize" id="location_map"></div>
                                                </div>

                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="latitude"><?php echo e(__('Latitude')); ?></label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" value="<?php echo e(old('latitude', $setting->lat)); ?>" name="latitude" id="latitude" placeholder="<?php echo e(__('Latitude')); ?>">
                                                        <?php $__errorArgs = ['latitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                            <div class="invalid-div"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>    
                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="longitude"><?php echo e(__('Longitude')); ?></label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" value="<?php echo e(old('longitude', $setting->long)); ?>" name="longitude" id="longitude" placeholder="<?php echo e(__('Longitude')); ?>">
                                                        <?php $__errorArgs = ['longitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                            <div class="invalid-div"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div> 

                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('setting_edit')): ?>
                                                    <div class="border-top">
                                                        <div class="card-body text-center">
                                                            <input type="submit" class="btn btn-primary rtl-float-none" value="<?php echo e(__('Submit')); ?>">
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            </form>
                                        </div>

                                        <!-- Push notification --->
                                        <div class="tab-pane fade" id="tab-3" role="tabpanel" aria-labelledby="tabs-icons-text-3-tab">
                                                <form action="<?php echo e(url('/admin/setting/push_notification')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <h3 class="card-title"><?php echo e(__('Push Notification')); ?></h3>
                                                
                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="enable_notification"><?php echo e(__('Notification')); ?> </label>
                                                    <div class="col-sm-9 mt-2">
                                                        <label class="custom-toggle">
                                                            <input type="checkbox" id="enable_notification" name="enable_notification" <?php echo e($setting->enable_notification == 1?'checked':''); ?>>
                                                            <span class="custom-toggle-slider rounded-circle" data-label-off="No" data-label-on="Yes"></span>
                                                        </label>
                                                    </div>
                                                </div>  
                                                
                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="app_id"><?php echo e(__('App ID')); ?></label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" value="<?php echo e(old('app_id', $setting->app_id)); ?>" name="app_id" id="app_id" placeholder="<?php echo e(__('App ID')); ?>">
                                                        <?php $__errorArgs = ['app_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                            <div class="invalid-div"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div> 

                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="api_key"><?php echo e(__('Api key')); ?></label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" value="<?php echo e(old('api_key', $setting->api_key)); ?>" name="api_key" id="api_key" placeholder="<?php echo e(__('Api key')); ?>">
                                                        <?php $__errorArgs = ['api_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                            <div class="invalid-div"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div> 

                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="auth_key"><?php echo e(__('Auth key')); ?></label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" value="<?php echo e(old('auth_key', $setting->auth_key)); ?>" name="auth_key" id="auth_key" placeholder="<?php echo e(__('Auth key')); ?>">
                                                        <?php $__errorArgs = ['auth_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                            <div class="invalid-div"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div> 

                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="project_no"><?php echo e(__('Project number')); ?></label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" value="<?php echo e(old('project_no', $setting->project_no)); ?>" name="project_no" id="project_no" placeholder="<?php echo e(__('Project number')); ?>">
                                                        <?php $__errorArgs = ['project_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                            <div class="invalid-div"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                                
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('setting_edit')): ?>
                                                    <div class="border-top">
                                                        <div class="card-body text-center">
                                                            <input type="submit" class="btn btn-primary rtl-float-none" value="<?php echo e(__('Submit')); ?>">
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            </form>
                                        </div>
                                        
                                        <!-- Email Settings --->
                                        <div class="tab-pane fade" id="tab-4" role="tabpanel" aria-labelledby="tabs-icons-text-4-tab">
                                            <form action="<?php echo e(url('/admin/setting/email_settings')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <h3 class="card-title"><?php echo e(__('Email Settings')); ?></h3>
                                                
                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="enable_mail"><?php echo e(__('Mail')); ?> </label>
                                                    <div class="col-sm-9 mt-2">
                                                        <label class="custom-toggle">
                                                            <input type="checkbox" id="enable_mail" name="enable_mail" <?php echo e($setting->enable_mail == 1?'checked':''); ?>>
                                                            <span class="custom-toggle-slider rounded-circle" data-label-off="No" data-label-on="Yes"></span>
                                                        </label>
                                                    </div>
                                                </div>  
                                                
                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="mail_host"><?php echo e(__('Mail Host')); ?></label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" value="<?php echo e(old('mail_host', $setting->mail_host)); ?>" name="mail_host" id="mail_host" placeholder="<?php echo e(__('Mail Host')); ?>">
                                                        <?php $__errorArgs = ['mail_host'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                            <div class="invalid-div"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div> 

                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="mail_port"><?php echo e(__('Mail Port')); ?></label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" value="<?php echo e(old('mail_port', $setting->mail_port)); ?>" name="mail_port" id="mail_port" placeholder="<?php echo e(__('Mail Port')); ?>">
                                                        <?php $__errorArgs = ['mail_port'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                            <div class="invalid-div"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div> 

                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="mail_username"><?php echo e(__('Mail Username')); ?></label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" value="<?php echo e(old('mail_username', $setting->mail_username)); ?>" name="mail_username" id="mail_username" placeholder="<?php echo e(__('Mail Username')); ?>">
                                                        <?php $__errorArgs = ['mail_username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                            <div class="invalid-div"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div> 

                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="mail_password"><?php echo e(__('Mail Password')); ?></label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" value="<?php echo e(old('mail_password', $setting->mail_password)); ?>" name="mail_password" id="mail_password" placeholder="<?php echo e(__('Mail Password')); ?>">
                                                        <?php $__errorArgs = ['mail_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                            <div class="invalid-div"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>

                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="sender_email"><?php echo e(__('Sender Email')); ?></label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" value="<?php echo e(old('sender_email', $setting->sender_email)); ?>" name="sender_email" id="sender_email" placeholder="<?php echo e(__('Sender Email')); ?>">
                                                        <?php $__errorArgs = ['sender_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                            <div class="invalid-div"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>  
                                                
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('setting_edit')): ?>
                                                    <div class="border-top">
                                                        <div class="card-body text-center">
                                                            <input type="submit" class="btn btn-primary rtl-float-none" value="<?php echo e(__('Submit')); ?>">
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            </form>
                                        </div>

                                        <!-- SMS Gateway --->
                                        <div class="tab-pane fade" id="tab-5" role="tabpanel" aria-labelledby="tabs-icons-text-5-tab">
                                            <form action="<?php echo e(url('/admin/setting/sms_gateway')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <h3 class="card-title"><?php echo e(__('SMS Gateway')); ?></h3>
                                                
                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="enable_sms"><?php echo e(__('SMS')); ?> </label>
                                                    <div class="col-sm-9 mt-2">
                                                        <label class="custom-toggle">
                                                            <input type="checkbox" id="enable_sms" name="enable_sms" <?php echo e($setting->enable_sms == 1?'checked':''); ?>>
                                                            <span class="custom-toggle-slider rounded-circle" data-label-off="No" data-label-on="Yes"></span>
                                                        </label>
                                                    </div>
                                                </div>  
                                                
                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="twilio_acc_id"><?php echo e(__('Twilio Account ID')); ?></label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" value="<?php echo e(old('twilio_acc_id', $setting->twilio_acc_id)); ?>" name="twilio_acc_id" id="twilio_acc_id" placeholder="<?php echo e(__('Twilio Account ID')); ?>">
                                                        <?php $__errorArgs = ['twilio_acc_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                            <div class="invalid-div"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div> 

                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="twilio_auth_token"><?php echo e(__('Twilio Auth Token')); ?></label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" value="<?php echo e(old('twilio_auth_token', $setting->twilio_auth_token)); ?>" name="twilio_auth_token" id="twilio_auth_token" placeholder="<?php echo e(__('Twilio Auth Token')); ?>">
                                                        <?php $__errorArgs = ['twilio_auth_token'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                            <div class="invalid-div"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div> 

                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="twilio_phone_no"><?php echo e(__('Twilio Phone Number')); ?></label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" value="<?php echo e(old('twilio_phone_no', $setting->twilio_phone_no)); ?>" name="twilio_phone_no" id="twilio_phone_no" placeholder="<?php echo e(__('Twilio Phone Number')); ?>">
                                                        <?php $__errorArgs = ['twilio_phone_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                            <div class="invalid-div"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div> 

                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('setting_edit')): ?>
                                                    <div class="border-top">
                                                        <div class="card-body text-center">
                                                            <input type="submit" class="btn btn-primary rtl-float-none" value="<?php echo e(__('Submit')); ?>">
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            </form>
                                        </div>

                                        <!-- Payment Gateway --->
                                        <div class="tab-pane fade" id="tab-6" role="tabpanel" aria-labelledby="tabs-icons-text-6-tab">
                                            <form action="<?php echo e(url('/admin/setting/payment_gateway')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <h3 class="card-title"><?php echo e(__('Payment Gateway')); ?></h3>
                                                
                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="cod"><?php echo e(__('COD')); ?> </label>
                                                    <div class="col-sm-9 mt-2">
                                                        <label class="custom-toggle">
                                                            <input type="checkbox" id="cod" name="cod" <?php echo e($payment->cod == 1?'checked':''); ?>>
                                                            <span class="custom-toggle-slider rounded-circle" data-label-off="No" data-label-on="Yes"></span>
                                                        </label>
                                                    </div>
                                                </div>
                                                
                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="paypal"><?php echo e(__('Paypal')); ?> </label>
                                                    <div class="col-sm-9 mt-2">
                                                        <label class="custom-toggle">
                                                            <input type="checkbox" id="paypal" name="paypal" <?php echo e($payment->paypal == 1?'checked':''); ?>>
                                                            <span class="custom-toggle-slider rounded-circle" data-label-off="No" data-label-on="Yes"></span>
                                                        </label>
                                                    </div>
                                                </div>
                                                    
                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="razorpay"><?php echo e(__('Razorpay')); ?> </label>
                                                    <div class="col-sm-9 mt-2">
                                                        <label class="custom-toggle">
                                                            <input type="checkbox" id="razorpay" name="razorpay" <?php echo e($payment->razorpay == 1?'checked':''); ?> <?php echo e($setting->currency_code != "INR"?'disabled':''); ?>>
                                                            <span class="custom-toggle-slider rounded-circle" data-label-off="No" data-label-on="Yes"></span>
                                                        </label>
                                                        <?php if($setting->currency_code != "INR"): ?>
                                                            <div class="mt-3">
                                                                <?php echo e(__("Rozarpay doesn't support")); ?> <?php echo e($setting->currency_code); ?>

                                                            </div>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            
                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="stripe"><?php echo e(__('Stripe')); ?> </label>
                                                    <div class="col-sm-9 mt-2">
                                                        <label class="custom-toggle">
                                                            <input type="checkbox" id="stripe" name="stripe" <?php echo e($payment->stripe == 1?'checked':''); ?>>
                                                            <span class="custom-toggle-slider rounded-circle" data-label-off="No" data-label-on="Yes"></span>
                                                        </label>
                                                    </div>
                                                </div>

                                                
                                                
                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="paypal_sandbox_key"><?php echo e(__('Paypal Sandbox Key')); ?></label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" value="<?php echo e(old('paypal_sandbox_key', $payment->paypal_sandbox_key)); ?>" name="paypal_sandbox_key" id="paypal_sandbox_key" placeholder="<?php echo e(__('Paypal Sandbox Key')); ?>">
                                                        <?php $__errorArgs = ['paypal_sandbox_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                            <div class="invalid-div"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div> 

                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="paypal_production_key"><?php echo e(__('Paypal Production Key')); ?></label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" value="<?php echo e(old('paypal_production_key', $payment->paypal_production_key)); ?>" name="paypal_production_key" id="paypal_production_key" placeholder="<?php echo e(__('Paypal Production Key')); ?>">
                                                        <?php $__errorArgs = ['paypal_production_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                            <div class="invalid-div"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div> 
                                                    
                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="razorpay_public_key"><?php echo e(__('Razorpay Public Key')); ?></label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" value="<?php echo e(old('razorpay_public_key', $payment->razorpay_public_key)); ?>" name="razorpay_public_key" id="razorpay_public_key" placeholder="<?php echo e(__('Razorpay Public Key')); ?>">
                                                        <?php $__errorArgs = ['razorpay_public_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                            <div class="invalid-div"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div> 

                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="razorpay_secret_key"><?php echo e(__('Razorpay Secret Key')); ?></label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" value="<?php echo e(old('razorpay_secret_key', $payment->razorpay_secret_key)); ?>" name="razorpay_secret_key" id="razorpay_secret_key" placeholder="<?php echo e(__('Razorpay Secret Key')); ?>">
                                                        <?php $__errorArgs = ['razorpay_secret_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                            <div class="invalid-div"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div> 
                                                    
                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="stripe_public_key"><?php echo e(__('Stripe Public Key')); ?></label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" value="<?php echo e(old('stripe_public_key', $payment->stripe_public_key)); ?>" name="stripe_public_key" id="stripe_public_key" placeholder="<?php echo e(__('Stripe Public Key')); ?>">
                                                        <?php $__errorArgs = ['stripe_public_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                            <div class="invalid-div"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div> 

                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="stripe_secret_key"><?php echo e(__('Stripe Secret Key')); ?></label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" value="<?php echo e(old('stripe_secret_key', $payment->stripe_secret_key)); ?>" name="stripe_secret_key" id="stripe_secret_key" placeholder="<?php echo e(__('Stripe Secret Key')); ?>">
                                                        <?php $__errorArgs = ['stripe_secret_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                            <div class="invalid-div"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div> 

                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('setting_edit')): ?>
                                                    <div class="border-top">
                                                        <div class="card-body text-center">
                                                            <input type="submit" class="btn btn-primary rtl-float-none" value="<?php echo e(__('Submit')); ?>">
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            </form>
                                        </div>
                                        
                                        <!-- Terms of use --->
                                        <div class="tab-pane fade" id="tab-7" role="tabpanel" aria-labelledby="tabs-icons-text-7-tab">
                                            <form action="<?php echo e(url('/admin/setting/terms_of_use')); ?>" id="terms_form" method="post">
                                                <?php echo csrf_field(); ?>
                                                <h3 class="card-title"><?php echo e(__('Terms Of Use')); ?></h3>
                                                <textarea class="terms_of_use form-control" rows="10" name="terms_of_use"><?php echo e($setting->terms_of_use); ?></textarea>

                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('setting_edit')): ?>
                                                    <div class="border-top">
                                                        <div class="card-body text-center">
                                                            <input type="submit" class="btn btn-primary rtl-float-none" value="<?php echo e(__('Submit')); ?>">
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            </form>
                                        </div>

                                        <!-- privacy_policy --->
                                        <div class="tab-pane fade" id="tab-8" role="tabpanel" aria-labelledby="tabs-icons-text-8-tab">
                                            <form action="<?php echo e(url('/admin/setting/privacy_policy')); ?>" id="privacy_form" method="post">
                                                <?php echo csrf_field(); ?>
                                                <h3 class="card-title"><?php echo e(__('Privacy Policy')); ?></h3>
                                                <textarea class="privacy_policy form-control" rows="10" name="privacy_policy"><?php echo e($setting->privacy_policy); ?></textarea>

                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('setting_edit')): ?>
                                                    <div class="border-top">
                                                        <div class="card-body text-center">
                                                            <input type="submit" class="btn btn-primary rtl-float-none" value="<?php echo e(__('Submit')); ?>">
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            </form>
                                        </div>

                                        <!-- App Setting --->
                                        <div class="tab-pane fade" id="tab-9" role="tabpanel" aria-labelledby="tabs-icons-text-9-tab">
                                            <form action="<?php echo e(url('/admin/setting/app_setting')); ?>" method="post" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                                <h3 class="card-title"><?php echo e(__('App Setting')); ?></h3>
                                                
                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label"><?php echo e(__('Select Unit')); ?></label>
                                                    <div class="col-sm-9 w-75">
                                                        <select class="form-control" dir="<?php echo e(session()->has('direction')&& session('direction') == 'rtl'? 'rtl':''); ?>" name="unit" id="unit" >
                                                            <option value="KG" <?php if($setting->cloth_unit == "KG"){ echo "selected"; } ?>> KG </option>
                                                            <option value="Cloth" <?php if($setting->cloth_unit == "Cloth"){ echo "selected"; } ?>> Cloth </option>
                                                        </select>
                                                    </div>
                                                </div>
                                                
                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="app_name"><?php echo e(__('App Name')); ?></label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" value="<?php echo e(old('app_name', $setting->app_name)); ?>" name="app_name" id="app_name" placeholder="<?php echo e(__('App Name')); ?>">
                                                        <?php $__errorArgs = ['app_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                            <div class="invalid-div"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div> 
                                                
                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="app_name"><?php echo e(__('Version')); ?></label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" value="<?php echo e(old('app_version', $setting->app_version)); ?>" name="app_version" id="app_version" placeholder="<?php echo e(__('Version')); ?>">
                                                        <?php $__errorArgs = ['app_version'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                            <div class="invalid-div"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div> 

                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label"><?php echo e(__('Favicon Icon')); ?></label>
                                                    <div class="">
                                                        <div class="col-sm-9 avatar-upload avatar-box">
                                                            <div class="avatar-edit">
                                                                <input type='file' id="image" name="image" accept=".png, .jpg, .jpeg" />
                                                                <label for="image"></label>
                                                            </div>
                                                            <div class="avatar-preview">
                                                                <div id="imagePreview" style="background-image: url(<?php echo e(url('/images/app/'.$setting->favicon)); ?>);">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label"><?php echo e(__('Black Logo')); ?></label>
                                                    <div class="">
                                                        <div class="col-sm-9 avatar-upload avatar-box">
                                                            <div class="avatar-edit">
                                                                <input type='file' id="image_edit" name="image_edit" accept=".png, .jpg, .jpeg" />
                                                                <label for="image_edit"></label>
                                                            </div>
                                                            <div class="avatar-preview">
                                                                <div id="imagePreview_edit" style="background-image: url(<?php echo e(url('/images/app/'.$setting->black_logo)); ?>);">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label"><?php echo e(__('White Logo')); ?></label>
                                                    <div class="">
                                                        <div class="col-sm-9 avatar-upload avatar-box">
                                                            <div class="avatar-edit">
                                                                <input type='file' id="image_edit_2" name="image_edit_2" accept=".png, .jpg, .jpeg" />
                                                                <label for="image_edit_2"></label>
                                                            </div>
                                                            <div class="avatar-preview">
                                                                <div id="imagePreview_edit_2" style="background-image: url(<?php echo e(url('/images/app/'.$setting->white_logo)); ?>);">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label"><?php echo e(__('Color Logo')); ?></label>
                                                    <div class="">
                                                        <div class="col-sm-9 avatar-upload avatar-box">
                                                            <div class="avatar-edit">
                                                                <input type='file' id="image_edit_3" name="image_edit_3" accept=".png, .jpg, .jpeg" />
                                                                <label for="image_edit_3"></label>
                                                            </div>
                                                            <div class="avatar-preview">
                                                                <div id="imagePreview_edit_3" style="background-image: url(<?php echo e(url('/images/app/'.$setting->color_logo)); ?>);">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label"><?php echo e(__('Login Screen')); ?></label>
                                                    <div class="">
                                                        <div class="col-sm-9 avatar-upload avatar-box">
                                                            <div class="avatar-edit">
                                                                <input type='file' id="image_edit_4" name="image_edit_4" accept=".png, .jpg, .jpeg" />
                                                                <label for="image_edit_4"></label>
                                                            </div>
                                                            <div class="avatar-preview">
                                                                <div id="imagePreview_edit_4" style="background-image: url(<?php echo e(url('/images/app/'.$setting->splash_screen)); ?>);">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('setting_edit')): ?>
                                                    <div class="border-top">
                                                        <div class="card-body text-center">
                                                            <input type="submit" class="btn btn-primary rtl-float-none" value="<?php echo e(__('Submit')); ?>">
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            </form>
                                        </div>
                                        
                                        <!-- Admin Settings --->
                                        <div class="tab-pane fade" id="tab-10" role="tabpanel" aria-labelledby="tabs-icons-text-10-tab">
                                            <form action="<?php echo e(url('/admin/setting/admin_settings')); ?>" method="post" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                                <h3 class="card-title"><?php echo e(__('Admin Settings')); ?></h3>

                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label"><?php echo e(__('Header Image')); ?></label>
                                                    <div class="">
                                                        <div class="col-sm-9 avatar-upload avatar-box">
                                                            <div class="avatar-edit">
                                                                <input type='file' id="image_edit_5" name="image_edit_5" accept=".png, .jpg, .jpeg" />
                                                                <label for="image_edit_5"></label>
                                                            </div>
                                                            <div class="avatar-preview">
                                                                <div id="imagePreview_edit_5" style="background-image: url(<?php echo e(url('/images/app/'.$setting->bg_img)); ?>);">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label"><?php echo e(__('No Data Found Image')); ?></label>
                                                    <div class="">
                                                        <div class="col-sm-9 avatar-upload avatar-box">
                                                            <div class="avatar-edit">
                                                                <input type='file' id="image_edit_6" name="image_edit_6" accept=".png, .jpg, .jpeg" />
                                                                <label for="image_edit_6"></label>
                                                            </div>
                                                            <div class="avatar-preview">
                                                                <div id="imagePreview_edit_6" style="background-image: url(<?php echo e(url('/images/app/'.$setting->no_data)); ?>);">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <label for="example-color-input" class="col-sm-3 text-right control-label col-form-label"><?php echo e(__('Color')); ?></label>
                                                    <input type="color" class="col-sm-9 form-control"  value="<?php echo e(old('color', $setting->color)); ?>" id="color" name="color" id="example-color-input">
                                                </div>

                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('setting_edit')): ?>
                                                    <div class="border-top">
                                                        <div class="card-body text-center">
                                                            <input type="submit" class="btn btn-primary rtl-float-none" value="<?php echo e(__('Submit')); ?>">
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            </form>
                                        </div>
                                        
                                        <!-- License --->
                                        <div class="tab-pane fade <?php echo e($setting->license_status == 0 ? 'active show': ''); ?>" id="tab-11" role="tabpanel" aria-labelledby="tabs-icons-text-11-tab">
                                            <form action="<?php echo e(url('/admin/setting/license')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <h3 class="card-title"><?php echo e(__('License')); ?></h3>
                                                
                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="license_code"><?php echo e(__('License Code')); ?></label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" value="<?php echo e(old('license_code', $setting->license_code)); ?>" name="license_code" id="license_code" placeholder="<?php echo e(__('License Code')); ?>" <?php echo e($setting->license_status == 1 ? 'disabled': ''); ?>>
                                                        <?php $__errorArgs = ['license_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                            <div class="invalid-div"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div> 

                                                <div class="form-group row">
                                                    <label class="col-sm-3 text-right control-label col-form-label" for="license_client_name"><?php echo e(__('License Client Name')); ?></label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" value="<?php echo e(old('license_client_name', $setting->license_client_name)); ?>" name="license_client_name" id="license_client_name" placeholder="<?php echo e(__('License Client Name')); ?>" <?php echo e($setting->license_status == 1 ? 'disabled': ''); ?>>
                                                        <?php $__errorArgs = ['license_client_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="invalid-div"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('setting_edit')): ?>
                                                    <?php if($setting->license_status == 0): ?>
                                                        <div class="border-top">
                                                            <div class="card-body text-center">
                                                                <input type="submit" class="btn btn-primary rtl-float-none" value="<?php echo e(__('Submit')); ?>">
                                                            </div>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_old\htdocs\App\resources\views/admin/setting/setting.blade.php ENDPATH**/ ?>