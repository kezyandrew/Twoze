<footer class="footer">
    <div class="container-fluid">
       
        <div class="copyright">
            &copy; <?php echo e(now()->year); ?> <?php echo e(_('made with')); ?> <i class="tim-icons icon-heart-2"></i>
            <span class="text-dark"><?php echo e(_('Laundering')); ?></span>
             <?php echo e(_('for a better web')); ?>.
        </div>
    </div>
</footer>
<?php /**PATH C:\xampp_old\htdocs\App\resources\views/layouts/footer.blade.php ENDPATH**/ ?>