
<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('layouts.breadcrumb', [
            'title' => __('Coupons'),
            'class' => 'col-lg-7'
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <!-- Page content -->
    <div class="container-fluid mt--6">
        <div class="row">
            <div class="col">
                <div class="card">
                    <!-- Card header -->
                    <div class="card-header">
                        <h3 class="mb-0"><?php echo e(__('Coupons table')); ?></h3>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('coupon_create')): ?>
                            <button class="btn btn-sm btn-primary float-right add_coupon mt--4" id="add_coupon"><i class="fa fa-plus mr-1"></i> <?php echo e(__('New')); ?></button>
                        <?php endif; ?>
                    </div>
                    <!-- Light table -->
                    <div class="table-responsive">
                        <table class="table align-items-center table-flush" id="dataTableReport">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col" class="sort"><?php echo e(__('#')); ?></th>
                                    <th scope="col" class="sort"><?php echo e(__('Code')); ?></th>
                                    <th scope="col" class="sort"><?php echo e(__('Max_use')); ?></th>
                                    <th scope="col" class="sort"><?php echo e(__('Use_count')); ?></th>
                                    <th scope="col" class="sort"><?php echo e(__('Discount')); ?></th>
                                    <th scope="col" class="sort"><?php echo e(__('Duration')); ?></th>
                                    <th scope="col" class="sort"><?php echo e(__('Status')); ?></th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody class="list">
                                <?php if(count($coupons) != 0): ?>
                                    <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th> <?php echo e($loop->iteration); ?> </th>
                                            <td> <?php echo e($coupon->code); ?> </td>
                                            <td> <?php echo e($coupon->max_use); ?> </td>
                                            <td> <?php echo e($coupon->use_count); ?> </td>
                                            <td>
                                                <?php if($coupon->type == "Amount"): ?>
                                                    <?php echo e($currency_symbol); ?><?php echo e($coupon->discount); ?>

                                                <?php else: ?>
                                                    <?php echo e($coupon->discount); ?><?php echo e(__('%')); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td> <?php echo e($coupon->start_date); ?> <?php echo e(__('-')); ?> <?php echo e($coupon->end_date); ?> </td>
                                            <td>
                                                <?php if($coupon->status == 1): ?>
                                                    <span class="badge badge-dot mr-4">
                                                        <i class="bg-success"></i>
                                                        <span class="status"><?php echo e(__('Active')); ?></span>
                                                    </span>
                                                <?php else: ?>
                                                    <span class="badge badge-dot mr-4">
                                                        <i class="bg-danger"></i>
                                                        <span class="status"><?php echo e(__('Inactive')); ?></span>
                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="table-actions">
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('coupon_access')): ?>
                                                    <button class="btn-white btn shadow-none p-0 m-0 table-action text-warning bg-white" onclick="show_coupon(<?php echo e($coupon->id); ?>)">
                                                        <i class="fas fa-eye"></i>
                                                    </button>
                                                <?php endif; ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('coupon_edit')): ?>
                                                    <button class="btn-white btn shadow-none p-0 m-0 table-action text-info bg-white" onclick="edit_coupon(<?php echo e($coupon->id); ?>)">
                                                        <i class="fa fa-edit"></i>
                                                    </button>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <?php $no_data = \App\Models\AppSetting::first()->no_data; ?>
                                    <tr>
                                        <td colspan="11" class="text-center">
                                            <img class="nodata-img" src="<?php echo e(asset('/images/app/'.$no_data)); ?>" alt="">
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('admin.coupon.couponCreate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.coupon.couponShow', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.coupon.couponEdit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_old\htdocs\App\resources\views/admin/coupon/couponTable.blade.php ENDPATH**/ ?>