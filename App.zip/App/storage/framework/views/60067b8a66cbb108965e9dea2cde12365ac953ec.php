<?php $bg_img = \App\Models\AppSetting::first()->bg_img; ?>

<div class="header pt-7" style="background-image: url(<?php echo e(asset('/images/app/'.$bg_img)); ?>); background-size: cover; background-position: center center;">
    <span class="mask bg-gradient-dark opacity-7"></span>
    <div class="container-fluid">
      <div class="header-body">
        <div class="row align-items-center py-4 pb-7">
          <div class="col-lg-6 col-7">
            <h6 class="h2 text-white d-inline-block mb-0"><?php echo e($title); ?></h6>
            <nav aria-label="breadcrumb" class="d-none d-md-inline-block">
              <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                  <li class="breadcrumb-item text-white"><a href="<?php echo e(url('admin/dashboard')); ?>"><i class="fa fa-home text-primary"></i></a></li>
                
                <?php if(isset($headerData) && $headerData): ?>
                    <li class="breadcrumb-item text-white"><a href="<?php echo e(url($url)); ?>" class=""><?php echo e($headerData); ?></a></li>
                <?php endif; ?>

                <li class="breadcrumb-item active text-white" aria-current="page"> <?php echo e($title); ?> </li>
              </ol>
            </nav>
          </div>
        </div>
      </div>
    </div>
</div><?php /**PATH C:\xampp_old\htdocs\App\resources\views/layouts/breadcrumb.blade.php ENDPATH**/ ?>