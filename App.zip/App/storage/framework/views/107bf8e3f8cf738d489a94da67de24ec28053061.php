<div class="container-fluid sidebar_open <?php if($errors->any()): ?> show_sidebar_create <?php endif; ?>" id="add_language_sidebar">
    <div class="row">
        <div class="col">
            <div class="card py-3 border-0">
                <!-- Card header -->
                <div class="border_bottom_primary pb-3 pt-2 mb-4">
                    <span class="h3"><?php echo e(__('Create Language')); ?></span>
                    <button type="button" class="add_language close">&times;</button>
                </div>
                <form class="form-horizontal"  id="create_language_form" method="post" enctype="multipart/form-data" action="<?php echo e(url('/admin/language')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="my-0">
                       
                        <div class="avatar-upload avatar-box">
                            <div class="avatar-edit">
                                <input type='file' id="image" name="image" accept=".png, .jpg, .jpeg" />
                                <label for="image"></label>
                            </div>
                            <div class="avatar-preview">
                                <div id="imagePreview" style="background-color: #f0f3f6;">
                                </div>
                            </div>
                        </div>
                        <div class="invalid-div text-center mt-3"><span class="image"></span></div>

                        <div class="form-group">
                            <label class="form-control-label" for="name"> <?php echo e(__('Name')); ?> <?php echo e(__('(Not Editable)')); ?> </label>
                            <input type="text" value="<?php echo e(old('name')); ?>" name="name" id="name" class="form-control" placeholder="<?php echo e(__('Language Name')); ?>" autofocus>
                            <div class="invalid-div "><span class="name"></span></div>
                        </div>
                        
                        <label class="form-control-label" for="language_file"> <?php echo e(__('Language JSON File')); ?> </label>
                        <div class="custom-file mb-3">
                            <input type="file" value="<?php echo e(old('language_file')); ?>" accept="Application/JSON" name="language_file" id="language_file" class="form-control">
                            <label class="custom-file-label" for="language_file"></label>
                            <div class="invalid-div "><span class="language_file"></span></div>
                        </div>
                        
                        
                        <div class="form-group">
                            <label class="form-control-label" for="direction"><?php echo e(__('Direction')); ?></label>
                            <select class="form-control" name="direction" value="<?php echo e(old('direction')); ?>">
                                <option value='ltr' selected><?php echo e(__('LTR')); ?></option>
                                <option value='rtl'><?php echo e(__('RTL')); ?></option>
                            </select>
                            <div class="invalid-div "><span class="direction"></span></div>
                        </div>

                        <div class="form-group">
                            <label class="form-control-label" for="status"><?php echo e(__('Status')); ?></label>
                            <select class="form-control" name="status"  value="<?php echo e(old('status')); ?>">
                                <option value='1' selected><?php echo e(__('Active')); ?></option>
                                <option value='0'><?php echo e(__('Inactive')); ?></option>
                            </select>
                            <div class="invalid-div "><span class="status"></span></div>
                        </div>
                        
                        <div class="text-center">
                            <button type="button" id="create_btn" onclick="all_create('create_language_form','language')" class="btn btn-primary mt-4 mb-5"><?php echo e(__('Create')); ?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp_old\htdocs\App\resources\views/admin/language/languageCreate.blade.php ENDPATH**/ ?>