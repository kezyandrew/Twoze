
<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('layouts.breadcrumb', [
            'title' => __('Offers'),
            'class' => 'col-lg-7'
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <!-- Page content -->
    <div class="container-fluid mt--6">
        <div class="row">
            <div class="col">
                <div class="card">
                    <!-- Card header -->
                    <div class="card-header">
                        <h3 class="mb-0"><?php echo e(__('Offers Table')); ?></h3>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('offer_create')): ?>
                            <button class="btn btn-sm btn-primary float-right add_offer mt--4" id="add_offer"><i class="fa fa-plus mr-1"></i> <?php echo e(__('New')); ?></button>
                        <?php endif; ?>
                    </div>
                    <!-- Light table -->
                    <div class="table-responsive">
                        <table class="table align-items-center table-flush" id="dataTableReport">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col" class="sort"><?php echo e(__('#')); ?></th>
                                    <th scope="col" class="sort"><?php echo e(__('Image')); ?></th>
                                    <th scope="col" class="sort"><?php echo e(__('Title 1')); ?></th>
                                    <th scope="col" class="sort"><?php echo e(__('Title 2')); ?></th>
                                    <th scope="col" class="sort"><?php echo e(__('Discount')); ?></th>
                                    <th scope="col" class="sort"><?php echo e(__('Status')); ?></th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody class="list">
                                <?php if(count($offers) != 0): ?>
                                    <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th> <?php echo e($loop->iteration); ?> </th>
                                            <td>
                                                <div class="avatar imageBox mr-3">
                                                    <img alt="Image placeholder imageBoxImg" src="<?php echo e(asset('/images/offer/'.$offer->image)); ?>">
                                                </div>
                                            </td>
                                            <td> <?php echo e($offer->title1); ?> </td>
                                            <td> <?php echo e($offer->title2); ?> </td>
                                            <td>
                                                <?php if($offer->type == "Amount"): ?>
                                                    <?php echo e($currency_symbol); ?><?php echo e($offer->discount); ?>

                                                <?php else: ?>
                                                    <?php echo e($offer->discount); ?><?php echo e(__('%')); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($offer->status == 1): ?>
                                                    <span class="badge badge-dot mr-4">
                                                        <i class="bg-success"></i>
                                                        <span class="status"><?php echo e(__('Active')); ?></span>
                                                    </span>
                                                <?php else: ?>
                                                    <span class="badge badge-dot mr-4">
                                                        <i class="bg-danger"></i>
                                                        <span class="status"><?php echo e(__('Inactive')); ?></span>
                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="table-actions">
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('offer_access')): ?>
                                                    <button class="btn-white btn shadow-none p-0 m-0 table-action text-warning bg-white" onclick="show_offer(<?php echo e($offer->id); ?>)">
                                                        <i class="fas fa-eye"></i>
                                                    </button>
                                                <?php endif; ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('offer_edit')): ?>
                                                    <button class="btn-white btn shadow-none p-0 m-0 table-action text-info bg-white" onclick="edit_offer(<?php echo e($offer->id); ?>)">
                                                        <i class="fa fa-edit"></i>
                                                    </button>
                                                <?php endif; ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('offer_delete')): ?>
                                                    <button class="btn-white btn shadow-none p-0 m-0 table-action text-danger bg-white" onclick="all_delete('admin/offer',<?php echo e($offer->id); ?>)">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <?php $no_data = \App\Models\AppSetting::first()->no_data; ?>
                                    <tr>
                                        <td colspan="11" class="text-center">
                                            <img class="nodata-img" src="<?php echo e(asset('/images/app/'.$no_data)); ?>" alt="">
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('admin.offer.offerCreate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.offer.offerShow', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.offer.offerEdit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_old\htdocs\App\resources\views/admin/offer/offerTable.blade.php ENDPATH**/ ?>