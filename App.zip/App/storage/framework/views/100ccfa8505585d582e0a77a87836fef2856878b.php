
<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('layouts.breadcrumb', [
            'title' => __('Roles'),
            'class' => 'col-lg-7'
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <!-- Page content -->
    <div class="container-fluid mt--6">
        <div class="row">
            <div class="col">
                <div class="card">
                    <!-- Card header -->
                    <div class="card-header">
                        <div class="mb-0 h3"><?php echo e(__('Roles Table')); ?></div>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_create')): ?>
                            <button class="btn btn-sm btn-primary float-right add_role mt--4" id="add_role"><i class="fa fa-plus mr-1"></i> <?php echo e(__('New')); ?></button>
                        <?php endif; ?>
                    </div>
                    <!-- Light table -->
                    <div class="table-responsive">
                        <table class="table align-items-center table-flush" id="dataTableReport">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col" class="sort table_num"><?php echo e(__('#')); ?></th>
                                    <th scope="col" class="sort table_title"><?php echo e(__('Title')); ?></th>
                                    <th scope="col" class="sort"><?php echo e(__('Permission')); ?></th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody class="list">
                                <?php if(count($roles) != 0): ?>
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th> <?php echo e($loop->iteration); ?> </th>
                                            <td> <?php echo e($role->title); ?> </td>
                                            <td>
                                                <?php if(count($role->permissions) != 0): ?>
                                                    <?php $__currentLoopData = $role->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <span class="badge badge-success"><?php echo e($per->title); ?></span>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    <span class="badge badge-danger">No data</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="table-actions">
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_edit')): ?>
                                                    <button class="btn-white btn shadow-none p-0 m-0 table-action text-info bg-white" onclick="edit_role(<?php echo e($role->id); ?>)">
                                                        <i class="fa fa-edit"></i>
                                                    </button>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <?php $no_data = \App\Models\AppSetting::first()->no_data; ?>
                                    <tr>
                                        <td colspan="11" class="text-center">
                                            <img class="nodata-img" src="<?php echo e(asset('/images/app/'.$no_data)); ?>" alt="">
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
<?php echo $__env->make('admin.role.roleCreate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.role.roleEdit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_old\htdocs\App\resources\views/admin/role/roleTable.blade.php ENDPATH**/ ?>